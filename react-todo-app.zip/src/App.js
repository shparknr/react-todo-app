import TodoTemplate from "./components/TodoTemplate";

function App() {
  return <TodoTemplate></TodoTemplate>;
}

export default App;
